Strange Matter server component benchmarks

Server components in a loaded flat world with no connected clients. Includes periodic machine state saves. Excludes startup, terrain generation, network round trips, client rendering, GUI interaction, and durable tube checkpoint throughput.

| Operation | Median | p95 | p99 | Allocation per operation |
| :--- | ---: | ---: | ---: | ---: |
| power_routes_32 | 4.61 us | 8.76 us | 13.85 us | 18408 bytes |
| power_routes_128 | 13.59 us | 15.68 us | 21.56 us | 72200 bytes |
| ingredients_36 | 6.00 us | 9.32 us | 10.46 us | 24680 bytes |
| ingredients_108 | 10.91 us | 13.18 us | 16.39 us | 28424 bytes |
| research_profile | 4.72 us | 5.66 us | 8.88 us | 16144 bytes |
| tube_plan_storage | 36.52 us | 39.62 us | 51.35 us | 66592 bytes |
| tube_plan_fuel | 32.52 us | 40.15 us | 53.55 us | 63432 bytes |
| machine_tick_16 | 29.10 us | 36.10 us | 90.40 us | 14968 bytes |
| machine_tick_64 | 98.00 us | 129.30 us | 218.80 us | 56101 bytes |
| tube_tick_128_idle | 0.10 us | 5.60 us | 99.40 us | 7753 bytes |

Run on: 25.0.1+8-LTS-27
CPU: Intel64 Family 6 Model 183 Stepping 1, GenuineIntel

These measurements are component timings, not client FPS or a promise of whole server tick times.
