Strange Matter server component benchmarks

Server components in a loaded flat world with no connected clients. Includes periodic machine state saves. Excludes startup, terrain generation, network round trips, client rendering, GUI interaction, and durable tube checkpoint throughput.

| Operation | Median | p95 | p99 | Allocation per operation |
| :--- | ---: | ---: | ---: | ---: |
| power_routes_32 | 3.14 us | 3.80 us | 5.84 us | 18408 bytes |
| power_routes_128 | 13.14 us | 15.60 us | 20.65 us | 72200 bytes |
| ingredients_36 | 6.09 us | 6.51 us | 7.54 us | 24552 bytes |
| ingredients_108 | 11.31 us | 12.81 us | 23.29 us | 28296 bytes |
| research_profile | 4.28 us | 5.95 us | 13.96 us | 16144 bytes |
| tube_plan_storage | 34.25 us | 42.33 us | 54.62 us | 65720 bytes |
| tube_plan_fuel | 30.25 us | 39.77 us | 66.33 us | 62712 bytes |
| machine_tick_16 | 24.00 us | 29.90 us | 41.80 us | 14469 bytes |
| machine_tick_64 | 91.90 us | 120.00 us | 227.40 us | 55223 bytes |
| tube_tick_128_idle | 0.10 us | 5.20 us | 106.50 us | 7753 bytes |

Run on: 25.0.1+8-LTS-27
CPU: Intel64 Family 6 Model 183 Stepping 1, GenuineIntel

These measurements are component timings, not client FPS or a promise of whole server tick times.
