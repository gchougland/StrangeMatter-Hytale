Strange Matter server component benchmarks

Server components in a loaded flat world with no connected clients. Includes periodic machine state saves. Excludes startup, terrain generation, network round trips, client rendering, GUI interaction, and durable tube checkpoint throughput.

| Operation | Median | p95 | p99 | Allocation per operation |
| :--- | ---: | ---: | ---: | ---: |
| power_routes_32 | 3.24 us | 3.61 us | 4.74 us | 18408 bytes |
| power_routes_128 | 13.30 us | 14.04 us | 14.89 us | 72200 bytes |
| ingredients_36 | 5.75 us | 6.61 us | 11.22 us | 24552 bytes |
| ingredients_108 | 11.18 us | 12.38 us | 14.54 us | 28296 bytes |
| research_profile | 4.71 us | 5.45 us | 10.93 us | 16240 bytes |
| tube_plan_storage | 37.50 us | 51.45 us | 75.88 us | 65744 bytes |
| tube_plan_fuel | 31.40 us | 38.08 us | 55.05 us | 62712 bytes |
| machine_tick_16 | 30.00 us | 61.30 us | 143.30 us | 14662 bytes |
| machine_tick_64 | 85.60 us | 123.30 us | 190.70 us | 56170 bytes |
| tube_tick_128_idle | 0.10 us | 5.70 us | 97.90 us | 7794 bytes |

Run on: 25.0.1+8-LTS-27
CPU: Intel64 Family 6 Model 183 Stepping 1, GenuineIntel

These measurements are component timings, not client FPS or a promise of whole server tick times.
